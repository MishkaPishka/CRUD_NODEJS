
class  Stock {

    constructor(name, symbol, sector){
        this.name = name;
        this.symbol = symbol;
        this.sector = sector;

    }

}

module.exports = Stock;

