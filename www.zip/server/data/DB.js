var express = require('express');
var app = express();
var path = require('path');

let Stock = require(path.resolve(__dirname, '../../server/Stock'));
let Sector = require(path.resolve(__dirname, '../../server/Sector'));


const MongoClient = require('mongodb').MongoClient;


class DB {


    constructor() {
        this.db = undefined
    }


    connectDB() {

        MongoClient.connect('mongodb://localhost/', (err, client) => {
            if (err) return console.log(err);
            this.db = client.db('company_db'); // whatever your database name is

        })
    }


    add_stock(stock) {
        return new Promise((resolve, reject) => {
            this.db.collection('companys').insert({Name: stock.name, Symbol: stock.symbol, Sector: stock.sector})
                .then(data => {
                    return resolve(stock);

                }).catch(err => reject(err))
        })


    }

    remove_stock(stock) {
        return new Promise((resolve, reject) => {
            this.db.collection('companys').findOneAndDelete({
                Name: stock.name,
                Symbol: stock.symbol,
                Sector: stock.sector
            })
                .then(data => {
                    return resolve(data);

                }).catch(err => reject(err))
        })

    }

    get_sectors_by_name() {
        return new Promise((resolve, reject) => {
            this.db.collection('companys').distinct('Sector')
                .then(data => {
                    return resolve(data);

                }).catch(err => reject(err))
        })

    }



    get_stock_by_name(name) {
        return new Promise((resolve, reject) => {
            this.db.collection('companys').findOne({'Name': name})
                .then(data => {
                    return resolve(data);
                    console.log('get_stock_by_name: ' + data);

                }).catch(err => reject(err))
        })

    }

    get_stocks_by_sector(sector) {
        let sector_name = sector.sector_name;
        return new Promise((resolve, reject) => {
            this.db.collection('companys').find({Sector: sector_name}).toArray()
                .then(data => {

                    return resolve(data);

                }).catch(err => reject(err))
        })

    }


    get_list_all() {
        return new Promise((resolve, reject) => {
            this.db.collection('companys').find().toArray()

                .then(data => {
                    // console.log(data);
                    return resolve(data);

                }).catch(err => reject(err))
        })


    }
}
module.exports = new DB();

