var express = require('express');
var router = express.Router();
var path = require('path');
let pp = path.resolve(__dirname, '../../data/DB');
let db = require(pp);
// console.log(z);
db.connectDB();
let Stock = require(path.resolve(__dirname, '../../Stock'));
let Sector = require(path.resolve(__dirname, '../../Sector'));


// STOCKS MAIN PAGE
router.get('/', function(req, res) {
    console.log("get - stocks_main");

    var stocks = null;

    return new Promise((resolve, reject) => {



        db.get_list_all()

            .then(data => {
                console.log("after list all companies");
                console.log(data);
                stocks = data;
                resolve(data);
            })
    }).then(_=> {
        res.render('stocks_main', { stocks: stocks});

    }) .catch(err => reject(err))

});

// //got a search query
// router.post('/', function(req, res, next) {
//     let name = req.body.name;
//     redirect_to_stock_page(name)
//
// });



//insert stock
router.post('/insert', function(req, res) {
    console.log("post - in insert");

    let symbol = req.body.symbol;
    let name = req.body.name;
    let sector = req.body.sector;
    console.log("insert: "+ symbol,name,sector);
    var stock = new Stock(name,symbol,sector);

    //TODO -> VALIDITIY CHECK


    //INSERT TO DAB
    console.log("search for: "+req.body.name);

    return new Promise( (resolve, reject) => {
        stock = db.add_stock(stock);
        if (stock == null) reject('no such stock');
        else resolve(stock);
    }).then(data => {

            console.log("redirect to stock page");
            res.redirect('/stocks/'+stock.name);
        })
        .catch(err => console.log(err));



}
);

router.post('/remove', function(req, res) {
    console.log("post - in remove");

    let name = req.body.name;
    console.log("remove: "+ name);

    //TODO -> VALIDITIY CHECK


    //INSERT TO DAB
    console.log("search for: "+req.body.name);
    var stock = db.get_stock_by_name(name);

    return new Promise( (resolve, reject) => {
        stock = db.remove_stock(stock);
        if (stock == null) reject('no such stock');
        else resolve(stock);
    }).then(data => {

        console.log("redirect to stocks ");
        res.redirect('/stocks');
    })
        .catch(err => console.log("*****"+err));



});


/* GET users listing. */
// router.post('/:name', function(req, res)
// {
//     let symbol = req.body.symbol;
//     let name = req.params.name;
//     let stock = db.change_symbol(name,symbol);
//     console.log(name,symbol);
//     res.render('stock', { stock: stock});
//
//
// });

/* GET users listing. */
router.get('/:name', function(req, res) {
    let name = req.params.name;
    console.log('get name;'+name);

    redirect_to_stock_page(req,res,name);

});

function redirect_to_stock_page(req,res,stock_name) {
    let stock = null;
    return new Promise( (resolve, reject) => {
        db.get_stock_by_name(stock_name)

            .then(data => {
                stock = data;
                resolve(data);

            })
    }).then(_=>
    {
        // res.redirect('/sectors/'+sector_name);
        res.render('stock', {stock: stock});
    })

        .catch(err => console.log(err));


}
module.exports = router;
