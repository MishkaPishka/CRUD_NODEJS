var express = require('express');
var router = express.Router();
var path = require('path');
let pp = path.resolve(__dirname, '../../data/DB');
let db = require(pp);

db.connectDB();

let Stock = require(path.resolve(__dirname, '../../Stock'));

let Sector = require(path.resolve(__dirname, '../../Sector'));

/* GET /sectors  */
router.get('/', function(req, res) {
    var sectors_list =null;
    var num_sectors = 0;
    return new Promise((resolve, reject) => {
        db.get_sectors_by_name().then(data=> {
            sectors_list = data;
            num_sectors = data.length;
            console.log('after get sectors');
            console.log('sectors_list:'+sectors_list);
            console.log('num_sectors:'+num_sectors);

            resolve(data);
        })



}).then(data=>{
        res.render('sectors_main', { sectors: sectors_list,num_sectors:num_sectors});
}).catch(err => reject(err))
})



/* GET /sectors/XXX. */
router.get('/:name', function(req, res, next) {
    let name = req.params.name;
    console.log('name: '+name);

    redirect_to_sector_page(req,res,name);

});


function redirect_to_sector_page(req,res,sector_name) {

    let sector = new Sector(sector_name);
    let stocks_by_sector =null;

    return new Promise( (resolve, reject) => {
        db.get_stocks_by_sector(sector)
            .then(data => {
                stocks_by_sector = data;
                resolve(data);

            })
    }).then(_=>
    {
        console.log('redirecting to sector: '+sector_name);
        // res.redirect('/sectors/'+sector_name);
        res.render('sector', {sector: sector, stocks_by_sector: stocks_by_sector});
    })

        .catch(err => console.log(err));




}

module.exports = router;

