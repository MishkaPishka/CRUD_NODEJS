class  Sector {

    constructor(sector_name){
        this.sector_name = sector_name;


    }

}

module.exports = Sector;

