//Data is in folder - create_db_data
To Create:
'mongoimport --db company_db --collection companys --type csv --headerline --file /path/toconstituents_csv.csv'



#TODO :
Finish middlewere for insert,delete,cheange.

#TODO:
add checks for correctness of input
